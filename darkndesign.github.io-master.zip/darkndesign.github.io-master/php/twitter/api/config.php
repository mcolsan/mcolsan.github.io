<?php
    /**
     * Your Twitter App Info


    // Consumer Key
    define('CONSUMER_KEY', 'CONSUMER_KEY_HERE');
    define('CONSUMER_SECRET', 'CONSUMER_SECRET_HERE');

    // User Access Token
    define('ACCESS_TOKEN', 'ACCESS_TOKEN_HERE');
    define('ACCESS_SECRET', 'ACCESS_SECRET_HERE');*/

    // Consumer Key
    define('CONSUMER_KEY', '8h0RpIEdyplJ6y2FDds44A');
    define('CONSUMER_SECRET', 'ijKGaLpFxJ4NhY4YpQgKkA2tRygViMhfuH6Y19mCxk');

    // User Access Token
    define('ACCESS_TOKEN', '160142183-drdwVVVuP93VyOAo5N1ij5kRqXTZOA55NIRTGmqp');
    define('ACCESS_SECRET', 'dyTPtIK4oPcjFzXAtQerC58sOebX0YDvZBrTMM2pkQ5ZD');

	// Cache Settings
	define('CACHE_ENABLED', false);
	define('CACHE_LIFETIME', 3600); // in seconds
	define('HASH_SALT', md5(dirname(__FILE__)));